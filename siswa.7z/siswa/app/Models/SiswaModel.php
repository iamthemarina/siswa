<?php namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
	protected $table = 'siswa';
	protected $primaryKey = 'id';

	protected $allowedFields = ['nisn', 'nama', 'angkatan', 'kelas', 'umur'];
	protected $useTimestamps = true;

	public function getSiswa($id = false){
	 if ($id == false){
	 		return $this->findAll();
	 	}
	 	return $this->where(['id' => $id])->first();
	 }
}