<?php namespace App\Controllers;

use App\Models\SiswaModel;

class Siswa extends BaseController
{
	//memanggil model siswa
	protected $siswaModel;
	public function __construct()
	{
		$this->siswaModel = new SiswaModel();
	}

	public function index()
	{
		$data = [
			'title' => 'Siswa',
			'siswa' => $this->siswaModel->findAll()
		];
		
		return view('siswa/index', $data);
	}

	public function detail($id)
	{
		$data = [
			'title' => 'detail-siswa',
			'siswa' => $this->siswaModel->getSiswa($id)
		];
		
		return view('siswa/detail', $data);
	}

	public function delete($id)
	{
		$this->siswaModel->delete($id);

		return redirect()->to('/siswa');
	}

	public function create()
	{
		$data = [
			'title' => 'Siswa'
		];
		
		return view('siswa/create', $data);
	}

	public function save()
	{
		if (!$this->validate([
			'nisn' => 'required',
			'nama'=>'required',
			'angkatan'=>'required',
			'umur'=>'required',
			'kelas'=>'required'
		])) {
			return redirect()->to('/siswa/create');
		}

		$this->siswaModel->save([
			'nisn' => $this->request->getVar('nisn'), 
			'nama'=> $this->request->getVar('nama'), 
			'angkatan' => $this->request->getVar('angkatan'), 
			'umur' => $this->request->getVar('umur'), 
			'kelas' => $this->request->getVar('kelas')
			]);

		session()->setFlashdata('pesan','Siswa Berhasil di Tambahkan');

			return redirect()->to('/siswa');
	}

	public function edit($id)
	{
		$data = [
			'title' => 'edit-siswa',
			'siswa' => $this->siswaModel->getSiswa($id)
		];
		
		return view('siswa/edit', $data);
	}

	public function update($id)
	{
		if (!$this->validate([
			'nisn' => 'required',
			'nama'=>'required',
			'angkatan'=>'required',
			'umur'=>'required',
			'kelas'=>'required'
		])) {
			return redirect()->to('/siswa/edit/'.$this->request->getVar('id'))->withInput();
			}

		$this->siswaModel->save([
			'id' => $id,
			'nisn'=> $this->request->getVar('nisn'), 
			'nama'=> $this->request->getVar('nama'), 
			'angkatan' => $this->request->getVar('angkatan'), 
			'umur' => $this->request->getVar('umur'), 
			'kelas' => $this->request->getVar('kelas')
			]);

		session()->setFlashdata('pesan','Siswa Berhasil di Update');

		return redirect()->to('/siswa');
	}
	//--------------------------------------------------------------------

}
