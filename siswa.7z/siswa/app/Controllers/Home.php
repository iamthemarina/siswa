<?php namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		$data = [
			'title' => 'Administrator Dashboard'
		];
		
		return view('dashboard/index', $data);
	}

	//--------------------------------------------------------------------

}
