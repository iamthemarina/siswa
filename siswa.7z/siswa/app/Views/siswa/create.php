<?= $this->extend('layout/index'); ?>

<?= $this->section('content'); ?>

<!-- Main Content -->
    <div id="content">

<!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="card mt=5">
  		<div class="card-body">
            <h5 class="card-title"><?= $title; ?></h5>
    			<p class="card-text">Penambahan Siswa</p>
        </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">           
     <form action="<?= base_url('siswa/save'); ?>" method="POST">
         <?= csrf_field(); ?>
      <div class="form-group">
        <label for="nisn">NISN</label>
          <input type="text" class="form-control" id="nisn" name="nisn" placeholder="100..">
    </div>
      <div class="form-group">
        <label for="nama">Nama</label>
          <input type="text" class="form-control" id="nama" name="nama" placeholder="Marina Sascya">
    </div>
    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="angkatan">Angkatan</label>
          <input type="text" class="form-control" id="angkatan" name="angkatan" placeholder="2015" >
    </div>
    <div class="form-group col-md-6">
        <label for="umur">Umur</label>
          <input type="text" class="form-control" id="umur" name="umur">
    </div>
    </div>
    <div class="form-group">
        <label for="kelas">Kelas</label>
          <input type="text" class="form-control" id="kelas" name="kelas" placeholder="XI">
  </div>
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Tambah Siswa</button>
</form>

</div>
    </div>
                
    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

<?= $this->endSection(); ?>