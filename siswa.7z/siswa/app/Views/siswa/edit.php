<?= $this->extend('layout/index'); ?>

<?= $this->section('content'); ?>

<!-- Main Content -->
    <div id="content">

<!-- Begin Page Content -->
    <div class="container-fluid">
        <div class="card mt=5">
  		<div class="card-body">
            <h5 class="card-title"><?= $title; ?></h5>
    			<p class="card-text">Detail Siswa</p>
        </div>
        </div>

        <div class="card mt-3">
          <div class="card-body">           
              <form action="<?= base_url('siswa/update/' .$siswa['id']); ?>" method="POST">
          <?= csrf_field(); ?>
      <div class="form-group">
        <label for="nisn">NISN</label>
            <input type="text" class="form-control" id="nisn" name="nisn" placeholder="100.." value="<?= $siswa['nisn']; ?>">
      </div>
      <div class="form-group">
      <label for="nama">Nama</label>
      <input type="text" class="form-control" id="nama" name="nama" placeholder="Marina Sascya" value="<?= $siswa['nama']; ?>">
      </div>
          <div class="form-row">
              <div class="form-group col-md-6">
                <label for="angkatan">Angkatan</label>
                    <input type="text" class="form-control" id="angkatan" name="angkatan" placeholder="2015" value="<?= $siswa['angkatan']; ?>">
      </div>
          <div class="form-group col-md-6">
              <label for="umur">Umur</label>
                    <input type="text" class="form-control" id="umur" name="umur" value="<?= $siswa['umur']; ?>">
          </div>
    </div>
      <div class="form-group">
            <label for="kelas">Kelas</label>
                    <input type="text" class="form-control" id="kelas" name="kelas" placeholder="XI" value="<?= $siswa['kelas']; ?>">
      </div>
    </label>
        </div>
      </div>
        <button type="submit" class="btn btn-primary">Ubah Siswa</button>
    </form>
    </div>
        </div>
              </div>
              <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

<?= $this->endSection(); ?>