<?= $this->extend('layout/index'); ?>

<?= $this->section('content'); ?>

<!-- Main Content -->
        <div id="content">

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <div class="card mt=5">
  				<div class="card-body">

    			<h5 class="card-title"><?= $title; ?></h5>
    				<p class="card-text">Detail Siswa</p>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-body">
                    <table class="table mt-2 ">
            <tr>
                <th scope="col">NISN</th>
                <td><?= $siswa['nisn']; ?></td>
            </tr>
            <tr>
                <th scope="col">Nama</th>
                <td><?= $siswa['nama']; ?></td>
            </tr>    
            <tr>
                <th scope="col">Angkatan</th>
                <td><?= $siswa['angkatan']; ?></td>
            </tr>
            <tr>
                <th scope="col">Kelas</th>
                <td><?= $siswa['kelas']; ?></td>
            </tr>
            <tr>
                <th scope="col">Umur</th>
                <td><?= $siswa['umur']; ?></td>
            </tr>
            <tr class="text-center">
                <td colspan="2">
                    <a href="<?= base_url('siswa/edit/'.$siswa['id']); ?>" class="btn btn-info">Edit</button>
                    <a href="<?= base_url('siswa/delete/'. $siswa['id']); ?>" class="btn btn-light" onclick="return confirm('apakah anda yakin ingin menghapusnya?');">Hapus</button>
                </td>
            </tr>
    </table>

                </div>
            </div>
                
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

<?= $this->endSection(); ?>