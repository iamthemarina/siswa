<?= $this->extend('layout/index'); ?>

<?= $this->section('content'); ?>

<!-- Main Content -->
            <div id="content">

<!-- Begin Page Content -->
            <div class="container-fluid">
                <div class="card mt=5">
  				<div class="card-body">
                    <?php if(session()->getFlashdata('pesan')): ?>
                    <div class="alert alert-info" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
            </div>
        <?php endif; ?>

    			<h5 class="card-title"><?= $title; ?></h5>
    				<p class="card-text">List Daftar Siswa</p>
                <table class="table">
            <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">NISN</th>
                <th scope="col">Nama</th>
                <th scope="col">Angkatan</th>
                <th scope="col">Aksi</th>
            </tr>
            
            </thead>
            <tbody>
                <!-- perulangan !-->
                <?php $i= 1; ?>
                <?php foreach($siswa as $s): ?>
            <tr>
                <th scope="row"><?= $i++; ?></th>
                <td><?= $s['nisn']; ?></td>
                <td><?= $s['nama']; ?></td>
                <td><?= $s['angkatan']; ?></td>
                <td><a href="<?= base_url('siswa/detail/'.$s['id']); ?>" button type="button" class="btn btn-outline-dark">Detail</button>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </div>
    </table>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

<?= $this->endSection(); ?>