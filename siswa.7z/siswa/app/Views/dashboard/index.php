<?= $this->extend('layout/index'); ?>

<?= $this->section('content'); ?>
<!-- Main Content -->
            <div id="content">

                <!-- Begin Page Content -->
                <div class="container-fluid">

                <div class="card mt=5">
  			<div class="card-body">
            
            <div class="jumbotron jumbotron-fluid">
            <div class="container">
            <h1 class="display-8">Daftar Siswa SMA Harapan Batam</h1>
            <p class="lead">SMA Harapan Batam, Batam Centre. Kepulauan Riau 29444</p>
            </div>
            </div>
    			<h5 class="card-title"><?= $title; ?></h5>
    				<p class="card-text">
  				</div>
			</div>
            <div class="card">
            <ul class="list-group list-group-flush">
            <li class="list-group-item">Nama - Marina Sascya</li>
            <li class="list-group-item">NIM -180155201005</li>
            </ul>
            </div>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800"></h1>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        

<?= $this->endSection(); ?>