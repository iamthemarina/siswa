-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2020 at 07:52 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id` int(15) NOT NULL,
  `nisn` varchar(250) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `angkatan` varchar(250) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `umur` int(250) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id`, `nisn`, `nama`, `angkatan`, `kelas`, `umur`, `created_at`, `updated_at`) VALUES
(1, '10001', 'Marina Sascya', '2015', 'X', 14, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, '10002', 'Raja Dini Kurnianingsih', '2014', 'XI', 15, '0000-00-00 00:00:00', '2020-12-10 02:41:10'),
(3, '10003', 'Dendi', '2014', 'XI', 16, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, '10004', 'Muhammad Fikriansyah', '2013', 'XII', 18, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, '10005', 'Fauzia Alfi Wahyuni', '2014', 'XI', 17, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, '10006', 'Kim Sunoo', '2015', 'X', 15, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, '10007', 'Mardesi Panca Irawan', '2014', 'XI', 16, '2020-12-09 03:58:46', '2020-12-09 03:58:46'),
(10, '10008', 'Raecca Ellysa', '2015', 'X', 16, '2020-12-09 04:53:08', '2020-12-10 03:18:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
